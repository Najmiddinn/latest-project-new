<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\News;
use Spatie\Translatable\HasTranslations;

class NewsCategory extends Model
{
	
	protected $table = 'news_category';
    protected $primaryKey = 'id';


    use HasTranslations;
    public $translatable = ['name'];


    protected $fillable = [
        
        'name',
        'parent',
        'order_by',
        'status',

    ];


    public $timestamps = false;

    
    public function getParent()
    {
        return $this->hasOne(self::class, 'id','parent');
    }




}






