<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;


class Branch extends Model
{

	protected $table = 'branch';
    protected $primaryKey = 'id';


    use HasTranslations;
    public $translatable = ['title','leader','address','leader_info'];


    protected $fillable = [

        'title',
        'leader',
        'phone',
        'email',
        'address',
        'leader_info',
        'image',
        'district_id',
        'status',
        'slug',
        'map_link',


    ];


    public $timestamps = false;

    public function getCategoryName() {
        return $this->hasOne(District::class,'id','district_id');
    }

//    public function getTagsName() {
//        return $this->belongToMany(Tags::class,'id','tags');
//    }

//    use HasTranslations;
//
//    public $translatable = ['news'];



}
