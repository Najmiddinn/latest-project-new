<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class ShortWord extends Model
{
    use HasFactory;
	
	protected $table = 'short_words';


    use HasTranslations;
    public $translatable = ['val'];


    protected $fillable = [
        'key',
        'val',
    ];


    public $timestamps = false;





}
