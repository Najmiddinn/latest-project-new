<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 17.04.2021
 * Time: 9:22
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class AdvertiseCategory extends Model
{
    protected $table = 'advertis_category';
    protected $primaryKey = 'id';


    use HasTranslations;
    public $translatable = ['name'];


    protected $fillable = [

        'name',
        'parent',
        'status',
        'order_by',


    ];


     public $timestamps = false;


    public function getParentName(){
        return $this->hasOne(self::class, 'id','parent');
    }

}