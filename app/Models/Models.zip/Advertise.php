<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;
use App\Models\AdvertiseCategory;

class Advertise extends Model
{

    protected $table = 'advertise';
    protected $primaryKey = 'id';


    use HasTranslations;
    public $translatable = ['name'];


    protected $fillable = [

        'name',
        'url',
        'image',
        'status',
        'category',
        'seen_count',
        'btn_click',
        'creator',


    ];


    // public $timestamps = false;

    public function getCategoryName() {
        return $this->hasOne(AdvertiseCategory::class,'id','category');
    }


}
