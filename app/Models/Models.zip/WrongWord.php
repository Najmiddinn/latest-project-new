<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class WrongWord extends Model
{
    use HasFactory;
	
	protected $table = 'wrong_words';




    protected $fillable = [
        'url',
        'wrong',
        'comment',
        'status',
        'ip',
    ];


    public $timestamps = false;





}
