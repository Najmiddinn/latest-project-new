<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class YoutubeVideos extends Model
{
    use HasFactory;

    protected $table = 'youtube_videos';
    protected $primaryKey = 'id';

    use HasTranslations;
    public $translatable = ['name'];




    protected $fillable = [
        'category',
        'name',
        'slug',
        'image',
        'link',
        'iframe',
        'status',
        'creator',


    ];


//    public $timestamps = false;


    public function getCategoryName() {
    return $this->hasOne(YoutubeVideosCategory::class,'id','category');
}





}
