<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class Page extends Model
{
    use HasFactory;
	
	protected $table = 'page';


    use HasTranslations;
    public $translatable = ['title','second_title','anons','body','image'];



    protected $fillable = [
        'title',
        'slug',
        'second_title',
        'anons',
        'body',
        'image',
        'creator',
        'created_at',
        'updated_at',
        'status',
        'icon',
        'seen_count',

    ];


    // public $timestamps = false;

     

    
}
