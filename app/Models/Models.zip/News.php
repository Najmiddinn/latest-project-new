<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\NewsCategory;
use Spatie\Translatable\HasTranslations;


class News extends Model
{

	protected $table = 'news';
    protected $primaryKey = 'id';


    use HasTranslations;
    public $translatable = ['title','second_title','anons','body','image'];


    protected $fillable = [

        'category',
        'title',
        'slug',
        'second_title',
        'anons',
        'body',
        'image',
        'created_at',
        'updated_at',
        'event_date',
        'status',
        'slider',
        'creator',
        'tags',
        'seen_count',

    ];


    // public $timestamps = false;

    public function getCategoryName() {
        return $this->hasOne(NewsCategory::class,'id','category');
    }

//    public function getTagsName() {
//        return $this->belongToMany(Tags::class,'id','tags');
//    }

    protected $guarded = [];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function comments()
    {
        return $this->morphMany(Comments::class, 'commentable')->whereNull('parent_id')->where(['status'=>1]);
    }



}
