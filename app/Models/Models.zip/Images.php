<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Album;
use Spatie\Translatable\HasTranslations;

class Images extends Model
{
    use HasFactory;
    
    protected $table = 'images';


    use HasTranslations;
    public $translatable = ['name'];


    protected $fillable = [
        'album',
        'name',
        'slug',
        'guid',
        'extension',
        'size',
        'creator',
        'status',
        'seen_count'

    ];

    public function getCategoryName() {
        return $this->hasOne(Album::class,'id','album');
    }

//    public $timestamps = false;

    

  

}
