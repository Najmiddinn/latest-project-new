<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class PostCategory extends Model
{
    use HasFactory;
	
	protected $table = 'post_category';


    use HasTranslations;
    public $translatable = ['name'];


    protected $fillable = [
        'name',
        'status',
        'order_by',
        'parent',
    ];


    public $timestamps = false;



    public function getParent()
    {
        return $this->hasOne(self::class, 'id','parent');
    }





}
