<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;


class District extends Model
{

	protected $table = 'district';
    protected $primaryKey = 'id';


    // use HasTranslations;
    // public $translatable = ['title','leader','address','leader_info'];


    protected $fillable = [

        'parent',
        'name',
        'order_by',
        'status',
     
    ];


    // public $timestamps = false;

    // public function getCategoryName() {
    //     return $this->hasOne(NewsCategory::class,'id','category');
    // }

//    public function getTagsName() {
//        return $this->belongToMany(Tags::class,'id','tags');
//    }

//    use HasTranslations;
//
//    public $translatable = ['news'];



}
