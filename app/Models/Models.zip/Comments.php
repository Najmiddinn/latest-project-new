<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;


class Comments extends Model
{

	protected $table = 'comments';

    protected $fillable = [

        'user_id',
        'parent_id',
        'body',
        'commentable_id',
        'commentable_type',
        'status',
       

    ];

    protected $guarded = [];
    
    public function user()
    {
        return $this->belongsTo(User::class);
    }


    public function replies(){
        return $this->hasMany(Comments::class,'parent_id')->where(['status'=>1]);
    }
    
    

    // public function getCategoryName() {
    //     return $this->hasOne(District::class,'id','district_id');
    // }


}
