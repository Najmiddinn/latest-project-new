<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class Tags extends Model
{
    use HasFactory;
    
    protected $table = 'tags';


    use HasTranslations;
    public $translatable = ['name'];


    protected $fillable = [
        
        'name',
        

    ];


    public $timestamps = false;

    

   

   
}
