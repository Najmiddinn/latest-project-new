<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

// use App\models\PostCategory;

class Post extends Model
{
    use HasFactory;
	
	protected $table = 'post';


    use HasTranslations;
    public $translatable = ['title','second_title','anons','body','image'];


    protected $fillable = [
        'category',
        'title',
        'slug',
        'second_title',
        'anons',
        'body',
        'image',
        'created_at',
        'updated_at',
        'event_date',
        'status',
        'slider',
        'creator',
        'tags',
        'seen_count',

    ];


    // public $timestamps = false;

    // public function category()
    // {
    //     return $this->belongToMany(PostCategory::class);
    // }



}
