<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class Album extends Model
{
    use HasFactory;

    protected $table = 'album';


    use HasTranslations;
    public $translatable = ['name','description'];

//    public $timestamps = false;

    protected $fillable = [
        
        'name',
        'slug',
        'description',
        'image',
        'status',
        'order_by',
        'creadet_at',
        'seen_count',
        'creator',

    ];






}
