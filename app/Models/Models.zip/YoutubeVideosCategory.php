<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;
use Illuminate\Http\Request;

class YoutubeVideosCategory extends Model
{
    use HasFactory;

    protected $table = 'youtube_viedos_category';

    protected $primaryKey = 'id';

    use HasTranslations;
    public $translatable = ['name'];




    protected $fillable = [
        'name',
        'status',
        'order_by',
        'parent',


    ];


    public $timestamps = false;



    public function getParent()
    {
        return $this->hasOne(self::class, 'id','parent');
    }








}
