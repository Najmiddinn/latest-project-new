<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 26.03.2021
 * Time: 18:27
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Emails extends Model
{
    use HasFactory;

    protected $table = 'emails';

    protected $fillable = [

        'name',


    ];


    public $timestamps = false;
}




